"""Sample intervals for the observer-centred GDAL viewshed grid."""
from dataclasses import dataclass
import math


def validate_spacing(mode, x, y):
    if mode not in ('square', 'meters', 'degrees', 'projection'):
        raise ValueError('روش تعیین فاصلهٔ نمونه‌برداری معتبر نیست.')
    if mode != 'square':
        for axis, value in (('X', x), ('Y', y)):
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
                raise ValueError(f'فاصلهٔ نمونه‌برداری محور {axis} باید عددی مثبت و متناهی باشد.')


def horizontal_reference(reference):
    from osgeo import osr
    ref = reference.Clone()
    if ref.IsCompound():
        ref.StripVertical()
    ref.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    return ref


def distances_in_metres(mode, x, y, lon, lat, local_crs, map_crs):
    """Convert map-axis intervals to local ground lengths at this observer."""
    if mode == 'meters':
        return x, y
    from osgeo import osr
    wgs = osr.SpatialReference()
    wgs.ImportFromEPSG(4326)
    wgs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    if mode == 'degrees':
        ref = wgs
        px, py = lon, lat
    elif mode == 'projection' and map_crs is not None:
        ref = horizontal_reference(map_crs)
        px, py, _ = osr.CoordinateTransformation(wgs, ref).TransformPoint(lon, lat)
    else:
        raise ValueError('سیستم مختصات افقی برای فاصلهٔ نمونه‌برداری مشخص نیست.')

    if ref.IsGeographic():
        radians = ref.GetAngularUnits()
        latitude = py * radians
        if not -math.pi / 2 < latitude < math.pi / 2:
            raise ValueError('فاصلهٔ طول جغرافیایی در قطب تعریف نمی‌شود.')
        # Ellipsoidal radii of curvature in the prime vertical and meridian.
        major = ref.GetSemiMajor()
        inverse_f = ref.GetInvFlattening()
        f = 1 / inverse_f if inverse_f else 0
        eccentricity_sq = f * (2 - f)
        denom = 1 - eccentricity_sq * math.sin(latitude) ** 2
        metres_x = major * math.cos(latitude) / math.sqrt(denom) * radians
        metres_y = major * (1 - eccentricity_sq) / denom ** 1.5 * radians
    elif ref.IsProjected():
        # A one-map-metre central difference includes the local projection
        # scale and the native unit (e.g. US survey feet).
        half = 0.5 / ref.GetLinearUnits()
        transform = osr.CoordinateTransformation(ref, local_crs)

        def scale(dx, dy):
            a = transform.TransformPoint(px - dx, py - dy)
            b = transform.TransformPoint(px + dx, py + dy)
            return math.hypot(b[0] - a[0], b[1] - a[1]) / (2 * half)

        metres_x, metres_y = scale(half, 0), scale(0, half)
    else:
        raise ValueError('برای فاصله در واحد نقشه، یک سیستم مختصات جغرافیایی یا تصویرشده انتخاب کنید.')
    return x * metres_x, y * metres_y


@dataclass(frozen=True)
class SamplingGrid:
    dx: float
    dy: float
    width: int
    height: int

    @property
    def bounds(self):
        east = self.width * self.dx / 2
        north = self.height * self.dy / 2
        return -east, -north, east, north

    def crop_padding(self, classes, transform):
        # GDAL accepts a single radial limit. On the finer axis it sometimes
        # retains an extra border cell per side. Use the same two-cell margin
        # as a square analysis at each axis's own spacing.
        height, width = classes.shape
        cols = max(0, (width - (self.width - 2)) // 2)
        rows = max(0, (height - (self.height - 2)) // 2)
        if self.dx == self.dy or not (rows or cols):
            return classes, transform
        x, dx, rx, y, ry, dy = transform
        return (classes[rows:height-rows, cols:width-cols],
                (x + cols * dx, dx, rx, y + rows * dy, ry, dy))


def _grid(radius, dx, dy):
    across, down = radius / dx, radius / dy
    if not math.isfinite(across) or not math.isfinite(down):
        raise ValueError('فاصلهٔ نمونه‌برداری برای این شعاع بسیار کوچک است.')
    # Three padding cells per side and an odd size keep the observer exactly
    # at the centre of a cell, including when X and Y have different steps.
    return SamplingGrid(dx, dy, 2 * math.ceil(across) + 7, 2 * math.ceil(down) + 7)


def plan_grid(radius, dx, dy, max_cells, auto_coarsen, fid, log):
    if not all(math.isfinite(v) and v > 0 for v in (radius, dx, dy)):
        raise ValueError('شعاع و فاصله‌های زمینی باید مثبت و متناهی باشند.')
    if radius < 2 * max(dx, dy):
        raise ValueError(f'FID={fid}: شعاع باید در هر محور حداقل دو پیکسل باشد. گام X و Y برابر {dx:g} و {dy:g} متر است.')
    requested = _grid(radius, dx, dy)
    if requested.width * requested.height <= max_cells:
        return requested

    if dx == dy:
        # Preserve the exact square-grid sizing used in earlier releases.
        radius_pixels = (math.isqrt(max_cells) - 7) // 2
        if radius_pixels < 2:
            raise ValueError('سقف شبکه برای تحلیل کافی نیست.')
        cell = math.nextafter(radius / radius_pixels, math.inf)
        fitted = _grid(radius, cell, cell)
        while fitted.width * fitted.height > max_cells:
            cell = math.nextafter(cell, math.inf)
            fitted = _grid(radius, cell, cell)
    else:
        # Both axes grow by one factor. Rounded, padded dimensions must fit
        # the actual budget and both axes must still resolve the radius.
        lo, hi = 1.0, (radius / 2) / max(dx, dy)
        fitted = _grid(radius, dx * hi, dy * hi)
        if fitted.width * fitted.height > max_cells:
            raise ValueError(f'FID={fid}: با این نسبت فاصله‌های X و Y، شبکه در سقف تعیین‌شده جا نمی‌شود. فاصلهٔ محور ریزتر یا سقف شبکه را افزایش دهید.')
        for _ in range(60):
            mid = math.sqrt(lo) * math.sqrt(hi)
            if not lo < mid < hi:
                break
            trial = _grid(radius, dx * mid, dy * mid)
            if trial.width * trial.height <= max_cells:
                hi, fitted = mid, trial
            else:
                lo = mid

    before = f'{requested.width}×{requested.height}'
    steps = f'X={fitted.dx:.8g}, Y={fitted.dy:.8g}'
    if not auto_coarsen:
        raise ValueError(f'FID={fid}: شبکهٔ درخواستی {before} از سقف {max_cells / 1e6:g} میلیون سلول بیشتر است. فاصلهٔ لازم با همین نسبت حداقل {steps} متر است. سقف یا فاصله‌ها را افزایش دهید یا تنظیم خودکار را روشن کنید.')
    log(f'نقطه {fid}: کاهش جزئیات برای سقف شبکه؛ {before} → {fitted.width}×{fitted.height}. فاصلهٔ واقعی {steps} متر.')
    return fitted


def grid_plan(radius, requested_cell, max_cells, auto_coarsen, fid, log):
    """Original square-grid API used by diagnostics and older callers."""
    grid = plan_grid(radius, requested_cell, requested_cell, max_cells, auto_coarsen, fid, log)
    return grid.dx, grid.width // 2, grid.width
