"""Offline batch processing, recorded desktop actions and the map history."""
from contextlib import closing, contextmanager
from datetime import datetime
from html import escape
import json
import math
from pathlib import Path
import sqlite3

from osgeo import gdal, osr
from PySide6 import QtCore, QtGui, QtWidgets


@contextmanager
def database(path):
    with closing(sqlite3.connect(path)) as connection, connection:
        yield connection


def attribute_row(feature):
    return {key: feature.GetFieldAsString(i) if feature.IsFieldSetAndNotNull(i) else None
            for i, key in enumerate(feature.keys())}


def historical_points(report):
    """Older reports store the exact observer at the origin of their local AEQD grid."""
    points = []
    original = None
    source = Path(report['settings']['points'])
    if report['observers'] and 'attributes' not in report['observers'][0] and source.is_file():
        try:
            original = gdal.OpenEx(str(source), gdal.OF_VECTOR | gdal.OF_READONLY,
                                   allowed_drivers=['ESRI Shapefile', 'GeoJSON'])
        except RuntimeError:
            pass  # The stored grid and analysis attributes still identify the point.
    wgs = osr.SpatialReference()
    wgs.ImportFromEPSG(4326)
    wgs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    for row in report['observers']:
        if 'attributes' in row:
            point = {key: row[key] for key in ('src_id', 'lon', 'lat', 'attributes')}
        else:
            local = osr.SpatialReference()
            local.ImportFromWkt(row['grid_crs'])
            local.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
            lon, lat, _ = osr.CoordinateTransformation(local, wgs).TransformPoint(0, 0)
            feature = original.GetLayer(0).GetFeature(row['src_id']) if original else None
            if feature is None:
                attributes = {k: row[k] for k in ('name', 'observer_at_point_m', 'receiver_on_cells_m', 'cell_m') if k in row}
                origin = 'گزارش تحلیل'
            else:
                attributes = attribute_row(feature)
                origin = 'جدول فعلی فایل مبدأ'
            point = dict(src_id=row['src_id'], lon=lon, lat=lat, attributes=attributes, origin=origin)
        if not (math.isfinite(point['lon']) and -90 <= point['lat'] <= 90):
            raise ValueError('مختصات نقطه در گزارش نامعتبر است.')
        points.append(point)
    return points


class HistoryPanel(QtWidgets.QWidget):
    """Keep committed results and the original attribute rows in the user's profile."""

    def __init__(self, window, project):
        super().__init__()
        self.window = window
        self.project = project
        self.path = window.workflow.path
        self.markers = {}
        self.color = QtGui.QColor(window.workflow.history_color)
        layout = QtWidgets.QVBoxLayout(self)
        self.list = QtWidgets.QListWidget()
        self.list.setAlternatingRowColors(True)
        import_button = QtWidgets.QPushButton('افزودن پوشهٔ نتایج قبلی…')
        import_button.clicked.connect(self.import_results)
        layout.addWidget(import_button)
        layout.addWidget(self.list)
        buttons = QtWidgets.QHBoxLayout()
        layout.addLayout(buttons)
        self.color_button = QtWidgets.QPushButton('رنگ نقاط تاریخچه…')
        self.color_button.clicked.connect(self.choose_color)
        buttons.addWidget(self.color_button)
        locate = QtWidgets.QPushButton('نمایش روی نقشه')
        locate.clicked.connect(self.locate)
        buttons.addWidget(locate)
        results = QtWidgets.QPushButton('باز کردن نتیجه')
        results.clicked.connect(self.open_result)
        buttons.addWidget(results)
        self.list.itemDoubleClicked.connect(self.locate)
        self.list.itemChanged.connect(self.toggle_layer)
        self.list.currentItemChanged.connect(self.raise_layer)
        self.update_swatch()
        try:
            with database(self.path) as db:
                db.execute('''CREATE TABLE IF NOT EXISTS runs (
                    folder TEXT PRIMARY KEY, source TEXT NOT NULL, finished TEXT NOT NULL,
                    points TEXT NOT NULL, visible INTEGER NOT NULL DEFAULT 1)''')
                for folder, source, finished, points, visible in db.execute(
                        'SELECT folder, source, finished, points, visible FROM runs ORDER BY rowid'):
                    self.add_layer(folder, source, finished, json.loads(points), bool(visible))
        except (OSError, sqlite3.Error, ValueError) as exc:
            window.show_error(f'خواندن تاریخچه ممکن نشد. {exc}')

    def remember(self, folder, report, finished=None):
        folder = str(Path(folder).resolve())
        if folder in self.markers or not report['observers']:
            return False
        points = historical_points(report)
        source = report['settings']['points']
        finished = (finished or datetime.now()).isoformat(timespec='seconds', sep=' ')
        with database(self.path) as db:
            db.execute('INSERT OR IGNORE INTO runs (folder, source, finished, points) VALUES (?, ?, ?, ?)',
                       (folder, source, finished, json.dumps(points, ensure_ascii=False)))
        self.add_layer(folder, source, finished, points, True)
        return True

    def import_results(self):
        folder = QtWidgets.QFileDialog.getExistingDirectory(self, 'پوشهٔ یک نتیجه یا پوشهٔ خروجی‌ها')
        if not folder:
            return
        root = Path(folder)
        reports = [root / 'run.json'] if (root / 'run.json').is_file() else sorted(root.glob('*/run.json'))
        added = failed = 0
        for path in reports:
            try:
                report = json.loads(path.read_text(encoding='utf-8'))
                if report['status'] != 'completed':
                    raise ValueError('گزارش اجرای کامل نیست.')
                added += self.remember(path.parent, report, datetime.fromtimestamp(path.stat().st_mtime))
            except (OSError, sqlite3.Error, ValueError, KeyError, TypeError, RuntimeError) as exc:
                failed += 1
                self.window.log.appendPlainText(f'{path} · {exc}')
        self.window.status.setText(f'{len(reports)} گزارش پیدا شد · {added} نتیجه به تاریخچه اضافه شد · {failed} خطا')

    def add_layer(self, folder, source, finished, points, visible):
        name = Path(source).name
        items = []
        for row in points:
            point = QtWidgets.QGraphicsEllipseItem(-5, -5, 10, 10)
            point.setPos(self.project(row['lon'], row['lat']))
            point.setFlag(QtWidgets.QGraphicsItem.ItemIgnoresTransformations)
            point.setBrush(self.color)
            point.setPen(QtGui.QPen(QtGui.QColor('white'), 1))
            point.setZValue(25)
            point.setVisible(visible)
            cells = ''.join(f'<tr><th>{escape(key)}</th><td>{escape(str(value)) if value is not None else "—"}</td></tr>'
                            for key, value in row['attributes'].items())
            origin = escape(row.get('origin', 'جدول اتریبیوت هنگام محاسبه'))
            point.setToolTip(f'<b>{escape(name)}</b> · FID {int(row["src_id"])}<br>{origin}<table>{cells}</table>')
            self.window.map_view.scene().addItem(point)
            items.append(point)
        self.markers[folder] = items
        entry = QtWidgets.QListWidgetItem(f'{name}  ·  {len(points)} نقطه  ·  {finished}')
        entry.setData(QtCore.Qt.UserRole, folder)
        entry.setToolTip(f'{source}\n{folder}')
        entry.setFlags(entry.flags() | QtCore.Qt.ItemIsUserCheckable)
        entry.setCheckState(QtCore.Qt.Checked if visible else QtCore.Qt.Unchecked)
        self.list.insertItem(0, entry)
        self.list.setCurrentItem(entry)

    def raise_layer(self, current, previous):
        for entry, z in ((previous, 25), (current, 26)):
            if entry is not None:
                for item in self.markers[entry.data(QtCore.Qt.UserRole)]:
                    item.setZValue(z)

    def toggle_layer(self, entry):
        folder = entry.data(QtCore.Qt.UserRole)
        visible = entry.checkState() == QtCore.Qt.Checked
        for item in self.markers[folder]:
            item.setVisible(visible)
        try:
            with database(self.path) as db:
                db.execute('UPDATE runs SET visible=? WHERE folder=?', (visible, folder))
        except sqlite3.Error as exc:
            self.window.show_error(f'ذخیرهٔ وضعیت نمایش تاریخچه ممکن نشد. {exc}')

    def locate(self):
        entry = self.list.currentItem()
        if entry is None:
            return
        entry.setCheckState(QtCore.Qt.Checked)
        view = self.window.map_view
        points = [item.pos() for item in self.markers[entry.data(QtCore.Qt.UserRole)]]
        xs, ys = [p.x() for p in points], [p.y() for p in points]
        bounds = QtCore.QRectF(min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys))
        margin = max(1000, max(bounds.width(), bounds.height()) * 0.12)
        self.window.tabs.setCurrentIndex(0)
        self.window.view_selector.setCurrentIndex(0)
        view.fitInView(bounds.adjusted(-margin, -margin, margin, margin), QtCore.Qt.KeepAspectRatio)
        view.initial_fit = False
        view.update_map_details()

    def open_result(self):
        entry = self.list.currentItem()
        if entry:
            QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(entry.data(QtCore.Qt.UserRole)))

    def choose_color(self):
        color = QtWidgets.QColorDialog.getColor(self.color, self, 'رنگ نقاط تاریخچه')
        if color.isValid():
            self.set_color(color.name())
            self.window.workflow.record('history_color', value=color.name())

    def set_color(self, value):
        self.color = QtGui.QColor(value)
        self.update_swatch()
        for layer in self.markers.values():
            for item in layer:
                item.setBrush(self.color)
        self.window.workflow.store_setting('map', 'color', self.color.name())

    def update_swatch(self):
        swatch = QtGui.QPixmap(16, 16)
        swatch.fill(self.color)
        self.color_button.setIcon(QtGui.QIcon(swatch))


class DesktopWorkflow(QtWidgets.QWidget):
    """Replay semantic commands on each input, waiting for each worker to finish."""

    def __init__(self, window):
        super().__init__()
        self.window = window
        self.active = False
        self.replaying = False
        self.waiting_for_map = False
        self.recording = None
        self.muted = False
        self.saved_run = False
        self.path = window.preferences.folder / 'analysis_history.sqlite'
        self.actions = {}
        self.mapping = {}
        self.history_color = '#a855f7'
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with database(self.path) as db:
                db.execute('''CREATE TABLE IF NOT EXISTS workflow_settings (
                    section TEXT, name TEXT, value TEXT NOT NULL, PRIMARY KEY (section, name))''')
                for section, name, value in db.execute('SELECT section, name, value FROM workflow_settings ORDER BY rowid'):
                    if section == 'columns':
                        self.mapping[name] = json.loads(value)
                    elif section == 'actions':
                        self.actions[name] = json.loads(value)
                    elif section == 'map' and name == 'color':
                        self.history_color = json.loads(value)
        except (OSError, sqlite3.Error, ValueError) as exc:
            window.show_error(f'خواندن تنظیمات گردش کار ممکن نشد. {exc}')
        # Apply units before numeric values, since unit changes adjust the spin-box limits.
        self.controls = {**window.unit_boxes, **{k: v for k, v in window.inputs.items() if k != 'points'},
                         **{k + '_from_field': v for k, v in window.height_modes.items()},
                         'resolution_factor': window.resolution, 'auto_coarsen': window.auto_coarsen,
                         'curvature_enabled': window.curvature, 'separate_outputs': window.separate,
                         'merge_coverage': window.merge, 'preview_mode': window.preview_mode,
                         'map_view': window.view_selector, 'country_labels': window.country_labels_toggle}
        for key, widget in self.controls.items():
            if isinstance(widget, QtWidgets.QComboBox):
                signal = widget.currentIndexChanged
            elif isinstance(widget, QtWidgets.QCheckBox):
                signal = widget.toggled
            elif isinstance(widget, QtWidgets.QLineEdit):
                signal = widget.editingFinished
            else:
                signal = widget.valueChanged
            signal.connect(lambda *_, name=key: self.changed(name))
        layout = QtWidgets.QVBoxLayout(self)
        self.name = QtWidgets.QLineEdit()
        self.name.setPlaceholderText('نام اکشن جدید')
        layout.addWidget(self.name)
        buttons = QtWidgets.QHBoxLayout()
        layout.addLayout(buttons)
        self.record_button = QtWidgets.QPushButton('●  ضبط')
        self.stop_button = QtWidgets.QPushButton('■  توقف و ذخیره')
        self.record_button.clicked.connect(self.start_recording)
        self.stop_button.clicked.connect(self.stop_recording)
        buttons.addWidget(self.record_button)
        buttons.addWidget(self.stop_button)
        self.record_status = QtWidgets.QLabel('')
        layout.addWidget(self.record_status)
        self.action_list = QtWidgets.QComboBox()
        self.action_list.addItems(self.actions)
        layout.addWidget(self.action_list)
        self.play_button = QtWidgets.QPushButton('▶  اجرای اکشن و ذخیره برای فایل‌های انتخابی')
        self.play_button.clicked.connect(self.play)
        layout.addWidget(self.play_button)
        hint = QtWidgets.QLabel('هنگام ضبط، تنظیمات و هر بار محاسبه به ترتیب ذخیره می‌شوند. اگر محاسبه‌ای ضبط نکنید، اکشن در پایان هر فایل یک بار محاسبه می‌کند.')
        hint.setWordWrap(True)
        layout.addWidget(hint)
        layout.addStretch()
        window.map_view.zoomed.connect(lambda factor: self.record('zoom', value=factor))
        window.map_view.panned.connect(lambda x, y: self.record('pan', x=x, y=y))
        window.preview_selector.activated.connect(
            lambda _: self.record('preview', value=window.preview_selector.currentData()))
        self.update_buttons()

    @contextmanager
    def quiet(self):
        previous = self.muted
        self.muted = True
        try:
            yield
        finally:
            self.muted = previous

    def store_setting(self, section, key, value):
        try:
            with database(self.path) as db:
                db.execute('INSERT OR REPLACE INTO workflow_settings VALUES (?, ?, ?)',
                           (section, key, json.dumps(value, ensure_ascii=False)))
        except sqlite3.Error as exc:
            self.window.show_error(f'ذخیرهٔ تنظیمات کاربر ممکن نشد. {exc}')

    def read(self, key):
        widget = self.controls[key]
        if isinstance(widget, QtWidgets.QComboBox):
            if key == 'combined_name_value':
                return {'text': widget.currentText(), 'index': widget.currentIndex()}
            data = widget.currentData()
            return widget.currentText() if data is None else data
        if isinstance(widget, QtWidgets.QCheckBox):
            return widget.isChecked()
        if isinstance(widget, QtWidgets.QLineEdit):
            return widget.text().strip()
        return widget.value()

    def write(self, key, value):
        widget = self.controls[key]
        if isinstance(widget, QtWidgets.QComboBox):
            if key == 'combined_name_value':
                # Rebind output naming to this input's distinct values.
                index = widget.findText(value['text'])
                if index < 0 and widget.count():
                    index = value['index'] if 0 <= value['index'] < widget.count() else 0
            else:
                index = widget.findData(value)
                if index < 0 and isinstance(value, str):
                    index = widget.findText(value, QtCore.Qt.MatchExactly | QtCore.Qt.MatchCaseSensitive)
                if index < 0 and key.endswith('_field') and value:
                    matches = [i for i in range(widget.count())
                               if widget.itemText(i).casefold() == value.casefold()]
                    if len(matches) == 1:
                        index = matches[0]
                    else:
                        widget.addItem(f'{value} (ستون پیدا نشد)', value)
                        index = widget.count() - 1
            widget.setCurrentIndex(index)
        elif isinstance(widget, QtWidgets.QCheckBox):
            widget.setChecked(value)
        elif isinstance(widget, QtWidgets.QLineEdit):
            widget.setText(value)
        else:
            widget.setValue(value)

    def changed(self, key):
        if self.muted or self.replaying:
            return
        value = self.read(key)
        if key.endswith(('_field', '_from_field', '_unit')) or key in ('sector_mode', 'combined_name_value'):
            self.mapping[key] = value
            self.store_setting('columns', key, value)
        self.record('set', key=key, value=value)
        # A unit change may restore both spin boxes without emitting their signals.
        if self.recording is not None and (key == 'spacing_mode' or
                (key == 'output_epsg' and self.read('spacing_mode') == 'projection')):
            for axis in ('spacing_x', 'spacing_y'):
                self.record('set', key=axis, value=self.read(axis))

    def restore_mapping(self):
        with self.quiet():
            for key in self.controls:
                if key in self.mapping:
                    self.write(key, self.mapping[key])

    def snapshot(self):
        return {key: self.read(key) for key in self.controls
                if key not in ('dem', 'output_dir') or self.read(key)}

    def update_buttons(self):
        self.record_button.setEnabled(not self.active and self.recording is None)
        self.stop_button.setEnabled(self.recording is not None)
        self.play_button.setEnabled(bool(self.actions) and not self.active and self.recording is None)
        self.record_status.setText(f'در حال ضبط · {len(self.recording["steps"])} گام'
                                   if self.recording is not None else '')
        tab = self.window.tabs.indexOf(self)
        if tab >= 0:
            self.window.tabs.setTabText(tab, '● در حال ضبط' if self.recording is not None else 'اکشن‌ها')

    def start_recording(self):
        if self.active or self.recording is not None:
            return
        self.recording = {'initial': self.snapshot(), 'steps': []}
        self.update_buttons()

    def record(self, op, **arguments):
        if self.recording is not None and not self.muted and not self.replaying:
            self.recording['steps'].append({'op': op, **arguments})
            self.update_buttons()

    def stop_recording(self):
        if self.recording is None:
            return
        base = self.name.text().strip() or 'اکشن'
        name = base
        suffix = 2
        value = json.dumps(self.recording, ensure_ascii=False)
        try:
            with database(self.path) as db:
                while not db.execute("INSERT OR IGNORE INTO workflow_settings VALUES ('actions', ?, ?)",
                                     (name, value)).rowcount:
                    name = f'{base} {suffix}'
                    suffix += 1
        except sqlite3.Error as exc:
            self.window.show_error(f'ذخیرهٔ اکشن ممکن نشد. {exc}')
            return
        self.actions[name] = self.recording
        self.recording = None
        self.action_list.addItem(name)
        self.action_list.setCurrentText(name)
        self.name.clear()
        self.update_buttons()

    def play(self):
        name = self.action_list.currentText()
        if self.recording is None and name in self.actions:
            self.begin(self.actions[name])

    def begin(self, action=None):
        if self.active:
            return
        w = self.window
        paths = w.selected_paths()
        if not paths or (len(paths) == 1 and paths[0] != w.loaded_shape):
            w.show_error('ابتدا ستون‌های شیپ‌فایل فعلی را بخوانید.')
            return
        self.replaying = action is not None
        if action is None:
            initial = self.snapshot()
            self.record('run', controls=initial)
            action = {'initial': initial, 'steps': []}
        self.initial = action['initial']
        if 'spacing_mode' not in self.initial:
            self.initial = {**self.initial, 'spacing_mode': 'square'}
        self.steps = list(action['steps'])
        if not any(step['op'] == 'run' for step in self.steps):
            self.steps.append({'op': 'run'})
        self.paths = paths
        self.index = -1
        self.step_index = 0
        self.failed_files = 0
        self.outputs_saved = 0
        self.points_saved = 0
        self.points_skipped = 0
        self.active = True
        self.next_file = True
        self.saved_run = False
        w.cancel_event.clear()
        w.form_widget.setEnabled(False)
        w.run_button.setEnabled(False)
        w.cancel_button.setEnabled(True)
        self.update_buttons()
        self.advance()

    def advance(self):
        if not self.active:
            return
        w = self.window
        if w.cancel_event.is_set():
            self.finish(cancelled=True)
            return
        try:
            with self.quiet():
                if self.next_file:
                    self.index += 1
                    if self.index == len(self.paths):
                        self.finish()
                        return
                    self.next_file = False
                    self.step_index = 0
                    self.pending_logs = []
                    path = self.paths[self.index]
                    w.result_folder = None
                    w.open_button.setEnabled(False)
                    w.log.appendPlainText(f'\nفایل {self.index + 1} از {len(self.paths)} · {path}')
                    w.select_current_path(path)
                    if w.loaded_shape != path:
                        w.load_fields(raise_errors=True)
                    for key, value in self.initial.items():
                        self.write(key, value)
                while self.step_index < len(self.steps):
                    step = self.steps[self.step_index]
                    if step['op'] in ('background', 'default_background') and w.map_thread is not None:
                        self.waiting_for_map = True
                        return
                    self.step_index += 1
                    if step['op'] == 'run':
                        for key, value in step.get('controls', {}).items():
                            self.write(key, value)
                        self.saved_run = False
                        w.launch_analysis()
                        return  # The worker signals completion after the files have been flushed.
                    self.apply_step(step)
                    if self.waiting_for_map:
                        return
                self.next_file = True
        except Exception as exc:
            self.file_error(str(exc))
        QtCore.QTimer.singleShot(0, self.advance)

    def apply_step(self, step):
        w = self.window
        op = step['op']
        if op == 'set':
            self.write(step['key'], step['value'])
        elif op == 'zoom':
            w.map_view.zoom_by(step['value'])
        elif op == 'pan':
            w.map_view.pan_relative(step['x'], step['y'])
        elif op == 'world':
            w.map_view.fit_world()
        elif op == 'points':
            w.fit_input_points()
        elif op == 'preview':
            index = w.preview_selector.findData(step['value'])
            if index >= 0:
                w.preview_selector.setCurrentIndex(index)
        elif op == 'history_color':
            w.history.set_color(step['value'])
        elif op == 'background':
            record = step['map']
            if w.preferences.data.get('map') != record:
                self.waiting_for_map = True
                w.start_map_load(record['path'], record.get('layer'), record.get('source_epsg'), persist=False)
        elif op == 'default_background':
            if w.preferences.data.get('map'):
                w.restore_background_map()
        elif op == 'read_fields':
            w.load_fields(raise_errors=True)
            for key, value in step['controls'].items():
                self.write(key, value)
        elif op == 'save_log':
            self.pending_logs.append((Path(step['name']).name, w.log.toPlainText()))
            if w.result_folder:
                self.flush_logs(w.result_folder)
        elif op == 'open_result':
            w.open_results()
        else:
            raise ValueError(f'گام ناشناخته در اکشن: {op}')

    def file_error(self, message):
        self.failed_files += 1
        self.next_file = True
        self.window.show_error(f'{self.paths[self.index]}\n{message}')

    def flush_logs(self, folder):
        if self.pending_logs:
            target = Path(folder) / 'logs'
            target.mkdir(exist_ok=True)
            for name, text in self.pending_logs:
                (target / name).write_text(text, encoding='utf-8')
            self.pending_logs.clear()

    def output_saved(self, folder, report):
        self.saved_run = True
        self.outputs_saved += 1
        self.points_saved += report['succeeded_records']
        self.points_skipped += report['skipped_count']
        self.flush_logs(folder)

    def map_finished(self, error):
        if self.active and self.waiting_for_map:
            self.waiting_for_map = False
            if error:
                self.file_error(error)
            self.advance()

    def worker_finished(self):
        if not self.active:
            return
        if not self.saved_run and not self.window.cancel_event.is_set():
            self.failed_files += 1
            self.next_file = True
        self.advance()

    def finish(self, cancelled=False):
        w = self.window
        self.active = False
        self.replaying = False
        self.waiting_for_map = False
        w.form_widget.setEnabled(True)
        w.run_button.setEnabled(True)
        w.cancel_button.setEnabled(False)
        self.update_buttons()
        if w._close_after_analysis:
            QtCore.QTimer.singleShot(0, w.close)
        if cancelled:
            message = f'صف لغو شد · {self.outputs_saved} نتیجه ذخیره شد.'
        elif len(self.paths) > 1:
            message = (f'پایان صف · {len(self.paths)} فایل، {self.outputs_saved} نتیجه ذخیره شد. '
                       f'{self.points_saved} نقطهٔ موفق، {self.points_skipped} رکورد ردشده، {self.failed_files} فایل با خطا')
        else:
            return
        w.status.setText(message)
        w.log.appendPlainText(message)
